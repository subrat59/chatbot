from django.db import models
from django.utils import timezone

class ChatHistory(models.Model):
    user_id = models.CharField(max_length=50)
    query = models.TextField()
    response = models.TextField()
    timestamp = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return self.query
class Register(models.Model):
    user_id=models.CharField(max_length=50)
    password=models.CharField(max_length=50)
    timestamp = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return self.query