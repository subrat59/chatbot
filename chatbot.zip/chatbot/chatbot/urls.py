from django.contrib import admin
from django.urls import path
from . import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.login),
    path('main/registration/',views.register),
    path('registration/',views.register),
    path('main/', views.store_message, name='store_message'),
    path('query/', views.query, name='query'),
    path('chat_history/', views.chat_history, name='chat-history'),
]