from django.http import HttpResponse
from django.shortcuts import render
from aichat.models import ChatHistory
from aichat.models import Register
from django.http import JsonResponse
from django.db import IntegrityError
def login(request):
    if request.method=='POST':
        username = request.POST.get('username')
        password=request.POST.get('password')
        user=Register.objects.filter(user_id=username)
        if(user):
            return HttpResponse("User already exist")
        else:
            userdetails = Register(user_id=username,password=password)
            userdetails.save()
            return render(request,'login.html')
    return render(request,'login.html')
def register(request):
    
    return render(request,'registration.html')
def store_message(request):
    if request.method == 'POST':
        user_id = request.POST.get('username')
        password=request.POST.get('password')
        user=Register.objects.filter(user_id=user_id,password=password)
        idonly=Register.objects.filter(user_id=user_id)
        if(user):
            return render(request, "main.html", {'user_id': user_id})
        elif idonly:
            context = {'invalidpswd': "Invalid Password"}
            return render(request, "login.html", context)
        else:
            context = {'invalidpswd': "Please Create Account"}
            return render(request, "login.html", context)
    return render(request, "login.html")
def query(request):
    if request.method == 'POST':
        message = request.POST.get('msg')
        userid=request.POST.get('username')
        print(userid,message)
        # Process the query and get the response string
        response_string = response(message)
        print(response_string)
        print("hello",userid)
        try:
            chat_query = ChatHistory(query=message,response=response_string,user_id=userid)
            chat_query.save()
            print("success")
        except IntegrityError as e:
            print("Database error:", str(e))
        # Return the response as a JSON object
        return JsonResponse({'response': response_string})
    else:
        return render(request, 'error.html')
def response(msg):
    return 'Hello ggtg'
def chat_history(request):
    if request.method == 'POST':
        userid=request.POST.get('usernam')
        print(userid)
        query_responses = ChatHistory.objects.filter(user_id=userid)
        context = {'chat_history': query_responses}
        return render(request, 'history.html', context)